const plans={
"Lunes":{type:"PILATES REFORMER",name:"Pilates reformer",level:"Control y movilidad",time:"35 min",symbol:"✿",ex:[["Footwork","3 series · 10 repeticiones"],["Puente de glúteos","3 series · 12 repeticiones"],["Brazos con resortes","2 series · 10 repeticiones"],["Estiramiento de columna","2 series · 8 repeticiones"]]},
"Martes":{type:"PILATES REFORMER",name:"Pilates reformer",level:"Centro y estabilidad",time:"35 min",symbol:"✿",ex:[["Respiración lateral","2 minutos"],["Footwork","3 series · 10 repeticiones"],["Trabajo de piernas","2 series · 10 repeticiones"],["Movilidad de columna","5 minutos"]]},
"Miércoles":{type:"FUERZA",name:"Fuerza",level:"Cuerpo completo",time:"50 min",symbol:"⚒",ex:[["Sentadilla con mancuernas","3 series · 10 repeticiones"],["Remo con mancuerna","3 series · 12 repeticiones"],["Press de pecho","3 series · 10 repeticiones"],["Peso muerto con mancuernas","3 series · 10 repeticiones"],["Plancha","3 series · 20 segundos"]]},
"Jueves":{type:"PILATES REFORMER",name:"Pilates reformer",level:"Postura y control",time:"35 min",symbol:"✿",ex:[["Footwork suave","3 series · 10 repeticiones"],["Puentes de glúteos","3 series · 12 repeticiones"],["Brazos con resortes","2 series · 10 repeticiones"],["Estiramientos","5 minutos"]]},
"Viernes":{type:"FUERZA",name:"Fuerza",level:"Glúteos y tren superior",time:"50 min",symbol:"⚒",ex:[["Hip thrust","3 series · 12 repeticiones"],["Press de hombros","3 series · 10 repeticiones"],["Remo con barra","3 series · 10 repeticiones"],["Zancadas","3 series · 10 por pierna"],["Dead bug","3 series · 10 por lado"]]},
"Sábado":{type:"FUERZA",name:"Fuerza",level:"Cuerpo completo",time:"45 min",symbol:"⚒",ex:[["Sentadilla sumo","3 series · 12 repeticiones"],["Remo con barra","3 series · 10 repeticiones"],["Press inclinado","3 series · 10 repeticiones"],["Curl de bíceps","3 series · 12 repeticiones"],["Caminata ligera","10 minutos"]]},
"Domingo":{type:"RECUPERACIÓN",name:"Descanso activo",level:"Recuperación suave",time:"15 min",symbol:"♧",ex:[["Paseo suave","10 minutos"],["Movilidad cómoda","5 minutos"]]}
};
const $=s=>document.querySelector(s);
const stateKey="alma-studio-state-v1";
let state={day:"Miércoles",checks:{},completed:[],weight:"",waist:""};
try{state={...state,...JSON.parse(localStorage.getItem(stateKey)||"{}")}}catch(e){}
let sessionIndex=0;
function save(){try{localStorage.setItem(stateKey,JSON.stringify(state))}catch(e){}}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function renderDays(){
 $("#days").innerHTML=Object.keys(plans).map(d=>`<button class="day ${state.day===d?'selected':''}" data-day="${d}"><span>${d.slice(0,3)}</span><span class="day-icon">${plans[d].symbol}</span><span class="tick">${state.completed.includes(d)?'✓':''}</span></button>`).join("");
 document.querySelectorAll("[data-day]").forEach(b=>b.addEventListener("click",()=>{state.day=b.dataset.day;save();renderPlan();}));
}
function renderPlan(){
 const p=plans[state.day];$("#workout-type").textContent=p.type;$("#workout-name").textContent=p.name;$("#workout-level").textContent=p.level;$("#workout-time").textContent=p.time;$("#workout-symbol").textContent=p.symbol;
 const checked=p.ex.filter((e,i)=>state.checks[state.day+"-"+i]).length;
 $("#exercise-count").textContent=`${checked} de ${p.ex.length} ejercicios`;$("#day-progress").style.width=(checked/p.ex.length*100)+"%";
 $("#exercise-list").innerHTML=p.ex.map((e,i)=>{const key=state.day+"-"+i,done=!!state.checks[key];return `<div class="exercise ${done?'done':''}"><input type="checkbox" id="ex-${i}" data-check="${i}" ${done?'checked':''}><label for="ex-${i}">${esc(e[0])}<small>${esc(e[1])}</small></label></div>`}).join("");
 document.querySelectorAll("[data-check]").forEach(el=>el.addEventListener("change",()=>{state.checks[state.day+"-"+el.dataset.check]=el.checked;save();renderPlan();}));
 renderDays();
}
function showView(name){document.querySelectorAll(".view").forEach(v=>v.classList.add("hidden"));$("#view-"+name).classList.remove("hidden");document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.view===name));if(name==="progress")renderProgress();window.scrollTo({top:0,behavior:"smooth"});}
function renderSession(){const p=plans[state.day],e=p.ex[sessionIndex];$("#session-title").textContent=state.day+" · "+p.name;$("#session-step").textContent=`EJERCICIO ${sessionIndex+1} DE ${p.ex.length}`;$("#session-exercise").textContent=e[0];$("#session-dose").textContent=e[1];$("#session-art").innerHTML=`<span>${p.symbol}</span>`;$("#prev-exercise").disabled=sessionIndex===0;$("#prev-exercise").style.opacity=sessionIndex===0?".45":"1";$("#next-exercise").textContent=sessionIndex===p.ex.length-1?"Finalizar sesión":"Siguiente";}
function renderProgress(){const days=state.completed.length;$("#completed-days").textContent=days;$("#week-progress").style.width=(days/7*100)+"%";$("#week-message").textContent=days===7?"¡Completaste tus siete sesiones!":days===0?"Tu progreso empieza con la primera sesión.":`Llevas ${days} ${days===1?"sesión":"sesiones"} completadas.`;$("#weight").value=state.weight||"";$("#waist").value=state.waist||"";$("#completed-list").innerHTML=state.completed.length?state.completed.map(d=>`<li>${esc(d)} · ${esc(plans[d].name)}</li>`).join(""):"<li>Aún no hay sesiones completadas.</li>";}
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));
$("#start-session").addEventListener("click",()=>{sessionIndex=0;renderSession();showView("session")});
$("#prev-exercise").addEventListener("click",()=>{sessionIndex=Math.max(0,sessionIndex-1);renderSession()});
$("#next-exercise").addEventListener("click",()=>{const p=plans[state.day];if(sessionIndex<p.ex.length-1){sessionIndex++;renderSession()}else{if(!state.completed.includes(state.day))state.completed.push(state.day);p.ex.forEach((e,i)=>state.checks[state.day+"-"+i]=true);save();renderPlan();renderProgress();showView("progress")}});
$("#back-plan").addEventListener("click",()=>showView("plan"));
$("#save-measures").addEventListener("click",()=>{state.weight=$("#weight").value;state.waist=$("#waist").value;save();$("#save-message").textContent="Medidas guardadas en este dispositivo.";});
$("#reset-week").addEventListener("click",()=>{if(confirm("¿Quieres reiniciar el registro semanal?")){state.completed=[];state.checks={};save();renderPlan();renderProgress()}});
renderPlan();renderProgress();
if("serviceWorker" in navigator){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));}
